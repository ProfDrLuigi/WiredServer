//
//  WIView.h
//  WiredFrameworks
//
//  Created by Rafaël Warnault on 11/03/13.
//  Copyright (c) 2013 Read-Write. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString * const     WIViewWillBecomeFirstResponderNotification;


@interface WIView : NSView

@end
